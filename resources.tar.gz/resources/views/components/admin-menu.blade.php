<div class="hcf-admin__menu">
    <ul class="hcf-admin__menu-items col-9">     
        <li class="">
            <button type="button" class="btn btn-primary">AJOUTER</button>
        </li>
    </ul>
    <div class="hcf-topnav__append col-3">
        
        <div class="hcf-admin__append-notify">
            <button type="button" class="btn btn-primary">EDIT</button>
        </div>
        
        <div class="hcf-admin__append-notify">
            <button type="button" class="btn btn-primary">DELETE</button>
        </div>
        
    </div>
</div>