@extends('layouts.shujin')

@section('content')
<div class="row mb-3">
    <div class="col-lg-3 col-md-6 col-sm-12 hcf-headline__block">
        <h3 class="hcf-headline__block-title">Lorem Ipsum <span class="badge badge-success">new</span></h3>
        <img src="https://place-hold.it/1280x720" class="img-fluid hcf-headline__block-header" alt="">
        <div class="hcf-headline__block-footer">
            <span class="badge badge-primary hcf-headline__block-footer_category">News</span>
            <span class="hcf-headline__block-footer_datetime"><i class="far fa-calendar-alt"></i> 22 jan. 2021</span>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-12 hcf-headline__block">
        <h3 class="hcf-headline__block-title">Lorem Ipsum</h3>
        <img src="https://place-hold.it/1280x720" class="img-fluid hcf-headline__block-header" alt="">
        <div class="hcf-headline__block-footer">
            <span class="badge badge-primary hcf-headline__block-footer_category">Association</span>
            <span class="hcf-headline__block-footer_datetime"><i class="far fa-calendar-alt"></i> 22 jan. 2021</span>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-12 hcf-headline__block">
        <h3 class="hcf-headline__block-title">Lorem Ipsum</h3>
        <img src="https://place-hold.it/1280x720" class="img-fluid hcf-headline__block-header" alt="">
        <div class="hcf-headline__block-footer">
            <span class="badge badge-primary hcf-headline__block-footer_category">Event</span>
            <span class="hcf-headline__block-footer_datetime"><i class="far fa-calendar-alt"></i> 22 jan. 2021</span>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-12 hcf-headline__block">
        <h3 class="hcf-headline__block-title">Lorem Ipsum</h3>
        <img src="https://place-hold.it/1280x720" class="img-fluid hcf-headline__block-header" alt="">
        <div class="hcf-headline__block-footer">
            <span class="badge badge-primary hcf-headline__block-footer_category">Tournament</span>
            <span class="hcf-headline__block-footer_datetime"><i class="far fa-calendar-alt"></i> 22 jan. 2021</span>
        </div>
    </div>
</div>
<div class="row mb-3">
    <div class="col-lg-3 col-md-6 col-sm-12">
        <div class="row">
            <div class="col-12 hcf-headline__block">
                <h3 class="hcf-headline__block-title">Streaming</h3>
                <img src="https://place-hold.it/1280x720" class="img-fluid" alt="">
            </div>
            <div class="col-12 hcf-headline__block">
                <h3 class="hcf-headline__block-title">Bracket</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsum odio temporibus nostrum molestiae magni atque provident dolores, nulla exercitationem dolorum quae suscipit omnis facere nesciunt iste culpa blanditiis expedita voluptatum!</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsum odio temporibus nostrum molestiae magni atque provident dolores, nulla exercitationem dolorum quae suscipit omnis facere nesciunt iste culpa blanditiis expedita voluptatum!</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsum odio temporibus nostrum molestiae magni atque provident dolores, nulla exercitationem dolorum quae suscipit omnis facere nesciunt iste culpa blanditiis expedita voluptatum!</p>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-12 hcf-headline__block">
        <h3 class="hcf-headline__block-title">Twitch Chat</h3>
    </div>
    <div class="col-lg-6 col-md-12 hcf-headline__block">
        <h3 class="hcf-headline__block-title">Ranking</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsum odio temporibus nostrum molestiae magni atque provident dolores, nulla exercitationem dolorum quae suscipit omnis facere nesciunt iste culpa blanditiis expedita voluptatum!</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsum odio temporibus nostrum molestiae magni atque provident dolores, nulla exercitationem dolorum quae suscipit omnis facere nesciunt iste culpa blanditiis expedita voluptatum!</p>
    </div>
</div>
@endsection